import win32gui
import win32process
import win32con
import win32api
import time
import win32com.client
import logging
from collections import OrderedDict

# 初始化Shell对象（核心：获取资源管理器路径）
shell = win32com.client.Dispatch("Shell.Application")
# 全局字典，记录文件资源管理器窗口信息：{窗口句柄: (路径, 打开时间)}
# 使用OrderedDict保持插入顺序（即打开顺序）
explorer_windows = OrderedDict()
# 数量限制：超过5个则关闭最早打开的窗口
max_windows = 5

def get_explorer_window_path(hwnd):
    """
    获取文件资源管理器窗口的路径（核心功能）
    """
    try:
        # 第一步：遍历Shell窗口，匹配句柄获取路径
        for window in shell.Windows():
            # 转换窗口句柄格式（兼容不同类型）
            if int(window.HWND) == hwnd:
                # 获取真实路径（处理URL格式为本地路径）
                path = window.LocationURL
                if path.startswith("file:///"):
                    # 解码URL格式（如 %20 转为空格）
                    import urllib.parse
                    path = urllib.parse.unquote(path).replace("file:///", "")
                    # 适配不同系统的路径分隔符
                    path = path.replace("/", "\\")
                return path
    except:
        # 若获取失败，用窗口标题替代（兼容不同系统版本）
        title = win32gui.GetWindowText(hwnd)
        return title

def is_explorer_window(hwnd):
    """
    判断指定窗口句柄是否为文件资源管理器窗口
    """
    # 跳过最小化的窗口（可选，根据需求调整）
    #if win32gui.IsIconic(hwnd):
    #    return False
    
    # 只处理可见的顶层窗口
    if not win32gui.IsWindowVisible(hwnd):
        return False
    
    # 获取窗口所属进程ID
    _, pid = win32process.GetWindowThreadProcessId(hwnd)
    
    # 通过PID获取进程名称（纯win32api实现，无psutil依赖）
    try:
        h_process = win32api.OpenProcess(win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ, False, pid)
        if h_process:
            exe_path = win32process.GetModuleFileNameEx(h_process, None)
            win32api.CloseHandle(h_process)
            process_name = exe_path.split("\\")[-1].lower()
        else:
            return False
    except:
        return False
    
    # 筛选出explorer.exe进程的窗口
    if process_name != "explorer.exe":
        return False
    
    # 确认窗口类名是文件资源管理器
    class_name = win32gui.GetClassName(hwnd)
    if class_name == "CabinetWClass":
        return True
    
    return False

def close_window(hwnd):
    """
    关闭指定句柄的窗口
    """
    try:
        # 发送关闭消息（模拟正常关闭）
        logging.info(f"已关闭窗口：{get_explorer_window_path(hwnd)} (句柄: {hwnd})")
        win32gui.PostMessage(hwnd, win32con.BM_CLICK, win32con.BN_CLICKED, 0)
        win32gui.SendMessage(hwnd, win32con.WM_CLOSE, 0, 0)
        # 移除已关闭窗口的记录
        if hwnd in explorer_windows:
            del explorer_windows[hwnd]
        return True
    except Exception as e:
        logging.info(f"关闭窗口失败：{e}")
        return False

def manage_explorer_windows():
    """
    管理文件资源管理器窗口：去重 + 数量限制
    """
    global explorer_windows
    # 临时字典，存储当前所有有效窗口
    current_windows = {}
    # 路径-窗口句柄映射（用于去重）
    path_to_hwnd = {}
    
    def callback(hwnd, extra):
        if is_explorer_window(hwnd):
            path = get_explorer_window_path(hwnd)
            current_time = time.time()
            
            # 去重逻辑：如果路径已存在，关闭当前窗口
            if path in path_to_hwnd:
                logging.info(f"发现重复路径窗口：{path}，关闭重复窗口（句柄: {hwnd}）")
                close_window(hwnd)
            else:
                path_to_hwnd[path] = hwnd
                current_windows[hwnd] = (path, current_time)
        return True
    
    # 枚举所有顶层窗口
    win32gui.EnumWindows(callback, None)
    
    # 更新全局窗口记录
    explorer_windows = OrderedDict(sorted(current_windows.items(), key=lambda x: x[1][1], reverse=True))

    while len(explorer_windows) > max_windows:
        # 获取最早打开的窗口句柄
        oldest_hwnd = next(iter(explorer_windows.keys()))
        close_window(oldest_hwnd)
    
    # 返回当前有效窗口数量
    return len(explorer_windows)

#def monitor_explorer_windows(interval=1):
#    """
#    实时监听并管理文件资源管理器窗口
#    :param interval: 监听间隔（秒）
#    """
#    logging.info("开始监听并管理文件资源管理器窗口（按 Ctrl+C 停止）...")
#    logging.info("规则：1. 相同路径只保留一个窗口 2. 最多保留5个窗口")
#    logging.info("-" * 80)
#    try:
#        while True:
#            window_count = manage_explorer_windows()
#            logging.info(f"\r当前有效文件资源管理器窗口数：{window_count}", end="")
#            time.sleep(interval)
#    except KeyboardInterrupt:
#        logging.info("\n\n监听已停止")
#
#if __name__ == "__main__":
#    # 安装依赖：pip install pywin32
#    monitor_explorer_windows(interval=1)