import os
import time
import ctypes
import socket
import logging
import threading
import subprocess
import configparser
import explorer

from datetime import datetime
from pathlib import Path

LOG_FILE = "D:\\logs\\logcat\\python.log"

class PortListener:
    def __init__(self, host='0.0.0.0', port=6666):
        self.host = host
        self.port = port
        self.running = False
        self.server_socket = None
        
    def start_listening(self):
        """启动端口监听服务"""
        try:
            # 创建TCP socket
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # 绑定地址和端口
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            self.running = True
            logging.info("####日志系统初始化成功")
            logging.info(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 开始监听端口 {self.port}")
            
            while self.running:
                try:
                    # 接受客户端连接
                    client_socket, client_address = self.server_socket.accept()
                    logging.info(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 客户端连接: {client_address}")
                    
                    # 为每个客户端创建新线程处理
                    client_thread = threading.Thread(
                        target=self.handle_client, 
                        args=(client_socket, client_address)
                    )
                    client_thread.daemon = True
                    client_thread.start()
                    
                except socket.error:
                    if self.running:
                        continue
                    break
                    
        except Exception as e:
            logging.info(f"监听端口时发生错误: {e}")
        finally:
            self.stop_listening()

    def handle_client(self, client_socket, client_address):
        """处理客户端连接"""
        try:
            # 接收客户端数据
            data = client_socket.recv(1024)
            if data:
                message = data.decode('utf-8')
                logging.info(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 来自 {client_address} 的消息: {message}")
                lines = data.splitlines()  # 按行分割为列表
                line_count = len(lines)    # 行数统计
                last_line = lines[-1] if lines else ""  # 安全获取最后一行
                path = last_line.decode('utf-8')
                logging.info(path)
                if os.path.exists(path):
                    if os.path.isfile(path):
                        logging.info(f"打开文件:{path}")
                        subprocess.Popen([f"{OpenFileApp}", path])
                    elif os.path.isdir(path):
                        logging.info(f"打开目录:{path}")
                        os.startfile(path)
                    else:
                        logging.info(f"未知路径")
                else:
                    logging.info(f"路径不存在")

                # 发送响应
                response = f"服务器已收到消息: {message}"
                client_socket.send(response.encode('utf-8'))
                
        except Exception as e:
            logging.info(f"处理客户端 {client_address} 时发生错误: {e}")
        finally:
            client_socket.close()
    
    def stop_listening(self):
        """停止监听服务"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        logging.info(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 已停止监听端口 {self.port}")

# 初始化日志
def setup_logger():
    try:
        log_path = Path(LOG_FILE)
        log_path.parent.mkdir(parents=True, exist_ok=True)  # 自动创建日志目录
        
        logging.basicConfig(
            filename=str(log_path),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        logging.info("日志系统初始化成功")
    except PermissionError as e:
        print(f"权限错误: {e}\n请检查日志目录写入权限")
    except Exception as e:
        print(f"日志初始化失败: {e}")

if __name__ == "__main__":
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)  # 隐藏窗口

    if os.path.exists(LOG_FILE): #每次脚本执行时判断日志文件是否存在，存在就删除，避免日志缓存过多
        os.remove(LOG_FILE)

    setup_logger()

    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(current_dir, "config.ini")
    # 实例化ConfigParser对象
    config = configparser.ConfigParser()
    # 读取ini文件
    config.read(f"{config_path}", encoding='utf-8')
    # 获取特定Config的OpenFileApp值
    OpenFileApp = config.get('Config', 'OpenFileApp')
    logging.info(f"OpenFileApp: {OpenFileApp}")
    # 创建监听器实例
    listener = PortListener(port=6666)
    # 在后台线程中启动监听
    listener_thread = threading.Thread(target=listener.start_listening)
    listener_thread.daemon = True
    listener_thread.start()
    
    logging.info("端口监听服务已启动，按Ctrl+C停止...")
    
    try:
        # 主线程保持运行
        while True:
            window_count = explorer.manage_explorer_windows()
            #print(f"\r当前有效文件资源管理器窗口数：{window_count}", end="")
            time.sleep(1)
    except KeyboardInterrupt:
        logging.info("\n正在停止服务...")
        listener.stop_listening()
