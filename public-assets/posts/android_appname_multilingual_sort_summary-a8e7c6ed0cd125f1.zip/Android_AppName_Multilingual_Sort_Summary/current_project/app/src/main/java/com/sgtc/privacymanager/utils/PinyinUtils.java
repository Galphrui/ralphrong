package com.sgtc.privacymanager.utils;

import android.icu.text.AlphabeticIndex;

import java.text.Normalizer;
import java.util.Locale;

/**
 * 应用名称首字母转换工具。
 *
 * <p>兼容 Android 8.1（API 27），不依赖第三方拼音库。</p>
 *
 * <p>处理规则：</p>
 * <ul>
 *     <li>中文：使用 Android ICU 的简体中文拼音索引获取 A-Z 首字母；</li>
 *     <li>英文：直接使用首字母；</li>
 *     <li>带重音的拉丁文字：去除重音后归入 A-Z；</li>
 *     <li>常见希腊文、俄文、日文假名、韩文、阿拉伯文和希伯来文：
 *         转换为对应的拉丁首字母；</li>
 *     <li>数字、符号、Emoji 或无法识别的文字：归入 #。</li>
 * </ul>
 */
public final class PinyinUtils {

    private static final String SPECIAL_GROUP = "#";
    private static final String LETTER_ORDER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    /**
     * AlphabeticIndex 从 API 24 开始提供。
     * 使用 zh_CN 索引时，简体中文按拼音 A-Z 分桶。
     * ImmutableIndex 是线程安全的，可供后台线程和主线程共同读取。
     */
    private static final AlphabeticIndex.ImmutableIndex<Object> CHINESE_INDEX =
            createChineseIndex();

    private PinyinUtils() {
    }

    private static AlphabeticIndex.ImmutableIndex<Object> createChineseIndex() {
        AlphabeticIndex<Object> index = new AlphabeticIndex<>(Locale.CHINA);
        index.addLabels(Locale.ENGLISH);
        return index.buildImmutableIndex();
    }

    /**
     * 获取应用名称的分组首字母。
     *
     * @param text 应用名称
     * @return A-Z 或 #
     */
    public static String getFirstSortLetter(String text) {
        if (text == null) {
            return SPECIAL_GROUP;
        }

        String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return SPECIAL_GROUP;
        }

        int firstCodePoint = trimmed.codePointAt(0);

        if (Character.isDigit(firstCodePoint)) {
            return SPECIAL_GROUP;
        }

        char latinLetter = foldLatinToAsciiInitial(firstCodePoint);
        if (latinLetter != 0) {
            return String.valueOf(latinLetter);
        }

        if (isChineseCodePoint(firstCodePoint)) {
            char chineseLetter = getChineseBucketLetter(
                    new String(Character.toChars(firstCodePoint))
            );
            return chineseLetter == 0
                    ? SPECIAL_GROUP
                    : String.valueOf(chineseLetter);
        }

        char scriptLetter = mapNonLatinScriptInitial(firstCodePoint);
        return scriptLetter == 0
                ? SPECIAL_GROUP
                : String.valueOf(scriptLetter);
    }

    /**
     * 获取单个汉字的拼音首字母。
     *
     * @param c 汉字
     * @return A-Z；不是汉字或无法识别时返回 null
     */
    public static Character getFirstPinyinLetter(char c) {
        if (!isChineseCodePoint(c)) {
            return null;
        }

        char letter = getChineseBucketLetter(String.valueOf(c));
        return letter == 0 ? null : letter;
    }

    /**
     * 生成用于非中文名称比较的稳定排序键。
     *
     * <p>中文名称的最终组内顺序由 NameSortUtils 中的中文 Collator 决定；
     * 此方法主要负责英文、带重音拉丁文字及常见非拉丁文字。</p>
     */
    public static String toSortKey(String text) {
        if (text == null) {
            return "";
        }

        String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return "";
        }

        StringBuilder result = new StringBuilder(trimmed.length());
        boolean previousWasSpace = false;

        for (int offset = 0; offset < trimmed.length(); ) {
            int codePoint = trimmed.codePointAt(offset);
            offset += Character.charCount(codePoint);

            if (Character.isWhitespace(codePoint)) {
                if (!previousWasSpace && result.length() > 0) {
                    result.append(' ');
                }
                previousWasSpace = true;
                continue;
            }

            previousWasSpace = false;

            if (Character.isDigit(codePoint)) {
                result.appendCodePoint(codePoint);
                continue;
            }

            char latinLetter = foldLatinToAsciiInitial(codePoint);
            if (latinLetter != 0) {
                result.append(Character.toLowerCase(latinLetter));
                continue;
            }

            if (isChineseCodePoint(codePoint)) {
                char chineseLetter = getChineseBucketLetter(
                        new String(Character.toChars(codePoint))
                );
                if (chineseLetter != 0) {
                    result.append(Character.toLowerCase(chineseLetter));
                } else {
                    result.appendCodePoint(codePoint);
                }
                continue;
            }

            char scriptLetter = mapNonLatinScriptInitial(codePoint);
            if (scriptLetter != 0) {
                result.append(Character.toLowerCase(scriptLetter));
            } else {
                result.appendCodePoint(Character.toLowerCase(codePoint));
            }
        }

        return result.toString().trim();
    }

    /**
     * 判断名称中是否包含中文字符。
     */
    public static boolean containsChinese(String text) {
        if (text == null || text.isEmpty()) {
            return false;
        }

        for (int offset = 0; offset < text.length(); ) {
            int codePoint = text.codePointAt(offset);
            if (isChineseCodePoint(codePoint)) {
                return true;
            }
            offset += Character.charCount(codePoint);
        }
        return false;
    }

    /**
     * 保留原工具类公开接口。
     */
    public static boolean isEnglishLetter(char c) {
        return (c >= 'a' && c <= 'z')
                || (c >= 'A' && c <= 'Z');
    }

    /**
     * 保留原工具类公开接口。
     */
    public static boolean isDigit(char c) {
        return Character.isDigit(c);
    }

    /**
     * 保留原工具类公开接口。
     *
     * <p>当前返回用于排序的拼音首字母小写形式。</p>
     */
    public static String getPinyinString(char c) {
        Character letter = getFirstPinyinLetter(c);
        return letter == null
                ? ""
                : String.valueOf(Character.toLowerCase(letter));
    }

    private static char getChineseBucketLetter(String chineseCharacter) {
        try {
            int bucketIndex = CHINESE_INDEX.getBucketIndex(chineseCharacter);
            AlphabeticIndex.Bucket<Object> bucket =
                    CHINESE_INDEX.getBucket(bucketIndex);

            if (bucket == null) {
                return 0;
            }

            return extractAsciiLetter(bucket.getLabel());
        } catch (RuntimeException ignored) {
            // ICU 数据异常时返回 0，由调用方归入 #，避免列表加载崩溃。
            return 0;
        }
    }

    private static char foldLatinToAsciiInitial(int codePoint) {
        if (codePoint >= 'a' && codePoint <= 'z') {
            return Character.toUpperCase((char) codePoint);
        }
        if (codePoint >= 'A' && codePoint <= 'Z') {
            return (char) codePoint;
        }

        char specialLetter = mapSpecialLatinLetter(codePoint);
        if (specialLetter != 0) {
            return specialLetter;
        }

        String source = new String(Character.toChars(codePoint));
        String normalized = Normalizer.normalize(source, Normalizer.Form.NFD);
        return extractAsciiLetter(normalized);
    }

    private static char extractAsciiLetter(String text) {
        if (text == null || text.isEmpty()) {
            return 0;
        }

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= 'a' && c <= 'z') {
                return Character.toUpperCase(c);
            }
            if (c >= 'A' && c <= 'Z') {
                return c;
            }
        }
        return 0;
    }

    private static char mapSpecialLatinLetter(int codePoint) {
        switch (codePoint) {
            case '\u00C6': // Æ
            case '\u00E6': // æ
                return 'A';

            case '\u0152': // Œ
            case '\u0153': // œ
            case '\u00D8': // Ø
            case '\u00F8': // ø
                return 'O';

            case '\u00D0': // Ð
            case '\u00F0': // ð
            case '\u0110': // Đ
            case '\u0111': // đ
                return 'D';

            case '\u00DE': // Þ
            case '\u00FE': // þ
                return 'T';

            case '\u0141': // Ł
            case '\u0142': // ł
                return 'L';

            case '\u00DF': // ß
                return 'S';

            case '\u0126': // Ħ
            case '\u0127': // ħ
                return 'H';

            case '\u0131': // ı
                return 'I';

            case '\u014A': // Ŋ
            case '\u014B': // ŋ
                return 'N';

            case '\u018F': // Ə
            case '\u0259': // ə
                return 'E';

            default:
                return 0;
        }
    }

    private static boolean isChineseCodePoint(int codePoint) {
        return (codePoint >= 0x3400 && codePoint <= 0x4DBF)
                || (codePoint >= 0x4E00 && codePoint <= 0x9FFF)
                || (codePoint >= 0xF900 && codePoint <= 0xFAFF)
                || (codePoint >= 0x20000 && codePoint <= 0x2A6DF)
                || (codePoint >= 0x2A700 && codePoint <= 0x2B73F)
                || (codePoint >= 0x2B740 && codePoint <= 0x2B81F)
                || (codePoint >= 0x2B820 && codePoint <= 0x2CEAF)
                || (codePoint >= 0x2CEB0 && codePoint <= 0x2EBEF)
                || (codePoint >= 0x2F800 && codePoint <= 0x2FA1F)
                || (codePoint >= 0x30000 && codePoint <= 0x3134F)
                || (codePoint >= 0x31350 && codePoint <= 0x323AF);
    }

    private static char mapNonLatinScriptInitial(int codePoint) {
        char greek = mapGreekInitial(codePoint);
        if (greek != 0) {
            return greek;
        }

        char cyrillic = mapCyrillicInitial(codePoint);
        if (cyrillic != 0) {
            return cyrillic;
        }

        char japanese = mapJapaneseInitial(codePoint);
        if (japanese != 0) {
            return japanese;
        }

        char korean = mapKoreanInitial(codePoint);
        if (korean != 0) {
            return korean;
        }

        char arabic = mapArabicInitial(codePoint);
        if (arabic != 0) {
            return arabic;
        }

        return mapHebrewInitial(codePoint);
    }

    private static char mapGreekInitial(int codePoint) {
        int upper = Character.toUpperCase(codePoint);
        switch (upper) {
            case 0x0391: return 'A'; // Α
            case 0x0392: return 'B'; // Β
            case 0x0393: return 'G'; // Γ
            case 0x0394: return 'D'; // Δ
            case 0x0395: return 'E'; // Ε
            case 0x0396: return 'Z'; // Ζ
            case 0x0397: return 'E'; // Η
            case 0x0398: return 'T'; // Θ
            case 0x0399: return 'I'; // Ι
            case 0x039A: return 'K'; // Κ
            case 0x039B: return 'L'; // Λ
            case 0x039C: return 'M'; // Μ
            case 0x039D: return 'N'; // Ν
            case 0x039E: return 'X'; // Ξ
            case 0x039F: return 'O'; // Ο
            case 0x03A0: return 'P'; // Π
            case 0x03A1: return 'R'; // Ρ
            case 0x03A3: return 'S'; // Σ
            case 0x03A4: return 'T'; // Τ
            case 0x03A5: return 'Y'; // Υ
            case 0x03A6: return 'F'; // Φ
            case 0x03A7: return 'C'; // Χ
            case 0x03A8: return 'P'; // Ψ
            case 0x03A9: return 'O'; // Ω
            default: return 0;
        }
    }

    private static char mapCyrillicInitial(int codePoint) {
        int upper = Character.toUpperCase(codePoint);
        switch (upper) {
            case 0x0410: return 'A'; // А
            case 0x0411: return 'B'; // Б
            case 0x0412: return 'V'; // В
            case 0x0413:
            case 0x0490: return 'G'; // Г, Ґ
            case 0x0414: return 'D'; // Д
            case 0x0415:
            case 0x0401:
            case 0x0404: return 'E'; // Е, Ё, Є
            case 0x0416: return 'Z'; // Ж
            case 0x0417: return 'Z'; // З
            case 0x0418:
            case 0x0419:
            case 0x0406:
            case 0x0407: return 'I'; // И, Й, І, Ї
            case 0x041A: return 'K'; // К
            case 0x041B: return 'L'; // Л
            case 0x041C: return 'M'; // М
            case 0x041D: return 'N'; // Н
            case 0x041E: return 'O'; // О
            case 0x041F: return 'P'; // П
            case 0x0420: return 'R'; // Р
            case 0x0421: return 'S'; // С
            case 0x0422: return 'T'; // Т
            case 0x0423: return 'U'; // У
            case 0x0424: return 'F'; // Ф
            case 0x0425: return 'H'; // Х
            case 0x0426: return 'C'; // Ц
            case 0x0427:
            case 0x040B: return 'C'; // Ч, Ћ
            case 0x0428:
            case 0x0429: return 'S'; // Ш, Щ
            case 0x042B: return 'Y'; // Ы
            case 0x042D: return 'E'; // Э
            case 0x042E: return 'Y'; // Ю
            case 0x042F: return 'Y'; // Я
            case 0x0402: return 'D'; // Ђ
            case 0x0405: return 'S'; // Ѕ
            case 0x0408: return 'J'; // Ј
            case 0x0409: return 'L'; // Љ
            case 0x040A: return 'N'; // Њ
            case 0x040F: return 'D'; // Џ
            default: return 0;
        }
    }

    private static char mapJapaneseInitial(int codePoint) {
        int hiragana = codePoint;

        // 片假名转换到对应平假名范围。
        if (codePoint >= 0x30A1 && codePoint <= 0x30F6) {
            hiragana = codePoint - 0x60;
        }

        switch (hiragana) {
            // A 行
            case 0x3041:
            case 0x3042:
            case 0x3043:
            case 0x3044:
            case 0x3045:
            case 0x3046:
            case 0x3047:
            case 0x3048:
            case 0x3049:
            case 0x304A:
                return 'A';

            // K / G 行
            case 0x304B:
            case 0x304D:
            case 0x304F:
            case 0x3051:
            case 0x3053:
                return 'K';
            case 0x304C:
            case 0x304E:
            case 0x3050:
            case 0x3052:
            case 0x3054:
                return 'G';

            // S / Z 行
            case 0x3055:
            case 0x3057:
            case 0x3059:
            case 0x305B:
            case 0x305D:
                return 'S';
            case 0x3056:
            case 0x3058:
            case 0x305A:
            case 0x305C:
            case 0x305E:
                return 'Z';

            // T / D 行
            case 0x305F:
            case 0x3061:
            case 0x3063:
            case 0x3064:
            case 0x3066:
            case 0x3068:
                return 'T';
            case 0x3060:
            case 0x3062:
            case 0x3065:
            case 0x3067:
            case 0x3069:
                return 'D';

            // N 行
            case 0x306A:
            case 0x306B:
            case 0x306C:
            case 0x306D:
            case 0x306E:
            case 0x3093:
                return 'N';

            // H / B / P 行
            case 0x306F:
            case 0x3072:
            case 0x3075:
            case 0x3078:
            case 0x307B:
                return 'H';
            case 0x3070:
            case 0x3073:
            case 0x3076:
            case 0x3079:
            case 0x307C:
                return 'B';
            case 0x3071:
            case 0x3074:
            case 0x3077:
            case 0x307A:
            case 0x307D:
                return 'P';

            // M 行
            case 0x307E:
            case 0x307F:
            case 0x3080:
            case 0x3081:
            case 0x3082:
                return 'M';

            // Y 行
            case 0x3083:
            case 0x3084:
            case 0x3085:
            case 0x3086:
            case 0x3087:
            case 0x3088:
                return 'Y';

            // R 行
            case 0x3089:
            case 0x308A:
            case 0x308B:
            case 0x308C:
            case 0x308D:
                return 'R';

            // W 行
            case 0x308E:
            case 0x308F:
            case 0x3090:
            case 0x3091:
            case 0x3092:
                return 'W';

            case 0x3094: // ゔ
                return 'V';

            default:
                return 0;
        }
    }

    private static char mapKoreanInitial(int codePoint) {
        if (codePoint < 0xAC00 || codePoint > 0xD7A3) {
            return 0;
        }

        int syllableIndex = codePoint - 0xAC00;
        int leadingConsonantIndex = syllableIndex / 588;
        int vowelIndex = (syllableIndex % 588) / 28;

        switch (leadingConsonantIndex) {
            case 0: return 'G';  // ㄱ
            case 1: return 'K';  // ㄲ
            case 2: return 'N';  // ㄴ
            case 3: return 'D';  // ㄷ
            case 4: return 'T';  // ㄸ
            case 5: return 'R';  // ㄹ
            case 6: return 'M';  // ㅁ
            case 7: return 'B';  // ㅂ
            case 8: return 'P';  // ㅃ
            case 9:
            case 10: return 'S'; // ㅅ, ㅆ
            case 11: return mapKoreanVowelInitial(vowelIndex); // ㅇ
            case 12:
            case 13: return 'J'; // ㅈ, ㅉ
            case 14: return 'C'; // ㅊ
            case 15: return 'K'; // ㅋ
            case 16: return 'T'; // ㅌ
            case 17: return 'P'; // ㅍ
            case 18: return 'H'; // ㅎ
            default: return 0;
        }
    }

    private static char mapKoreanVowelInitial(int vowelIndex) {
        switch (vowelIndex) {
            case 0:
            case 1:
                return 'A';
            case 2:
            case 3:
            case 6:
            case 7:
            case 12:
            case 17:
                return 'Y';
            case 4:
            case 5:
            case 18:
                return 'E';
            case 8:
            case 11:
                return 'O';
            case 9:
            case 10:
            case 14:
            case 15:
            case 16:
                return 'W';
            case 13:
                return 'U';
            case 19:
                return 'U';
            case 20:
                return 'I';
            default:
                return 0;
        }
    }

    private static char mapArabicInitial(int codePoint) {
        switch (codePoint) {
            case 0x0627:
            case 0x0622:
            case 0x0623:
            case 0x0625:
            case 0x0671:
            case 0x0639:
                return 'A';
            case 0x0628: return 'B';
            case 0x062A:
            case 0x062B:
            case 0x0637:
                return 'T';
            case 0x062C: return 'J';
            case 0x062D:
            case 0x0647:
                return 'H';
            case 0x062E: return 'K';
            case 0x062F:
            case 0x0630:
            case 0x0636:
                return 'D';
            case 0x0631: return 'R';
            case 0x0632:
            case 0x0698:
            case 0x0638:
                return 'Z';
            case 0x0633:
            case 0x0634:
            case 0x0635:
                return 'S';
            case 0x063A:
            case 0x06AF:
                return 'G';
            case 0x0641: return 'F';
            case 0x0642: return 'Q';
            case 0x0643: return 'K';
            case 0x0644: return 'L';
            case 0x0645: return 'M';
            case 0x0646: return 'N';
            case 0x0648: return 'W';
            case 0x064A:
            case 0x0649:
                return 'Y';
            case 0x067E: return 'P';
            case 0x0686: return 'C';
            default: return 0;
        }
    }

    private static char mapHebrewInitial(int codePoint) {
        switch (codePoint) {
            case 0x05D0:
            case 0x05E2:
                return 'A';
            case 0x05D1: return 'B';
            case 0x05D2: return 'G';
            case 0x05D3: return 'D';
            case 0x05D4:
            case 0x05D7:
                return 'H';
            case 0x05D5: return 'V';
            case 0x05D6: return 'Z';
            case 0x05D8:
            case 0x05EA:
                return 'T';
            case 0x05D9: return 'Y';
            case 0x05DA:
            case 0x05DB:
            case 0x05E7:
                return 'K';
            case 0x05DC: return 'L';
            case 0x05DD:
            case 0x05DE:
                return 'M';
            case 0x05DF:
            case 0x05E0:
                return 'N';
            case 0x05E1:
            case 0x05E9:
                return 'S';
            case 0x05E3:
            case 0x05E4:
                return 'P';
            case 0x05E5:
            case 0x05E6:
                return 'C';
            case 0x05E8: return 'R';
            default: return 0;
        }
    }
}
