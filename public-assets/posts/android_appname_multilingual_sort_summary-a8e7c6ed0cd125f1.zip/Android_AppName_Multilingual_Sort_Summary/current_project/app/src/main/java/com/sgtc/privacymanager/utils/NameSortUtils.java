package com.sgtc.privacymanager.utils;

import com.sgtc.privacymanager.data.model.AppEntryItem;
import com.sgtc.privacymanager.data.model.AppInfo;
import com.sgtc.privacymanager.data.model.LetterHeaderItem;
import com.sgtc.privacymanager.data.model.ListItem;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 应用名称排序与分组工具类。
 *
 * <p>排序规则：</p>
 * <ul>
 *     <li>中文按第一个汉字的拼音首字母分组；</li>
 *     <li>英文按首字母分组；</li>
 *     <li>带重音的拉丁文字按去重音后的首字母分组；</li>
 *     <li>常见非拉丁文字按拉丁化首字母分组；</li>
 *     <li>数字、符号、Emoji 和无法识别的名称归入 #；</li>
 *     <li>组间固定按 A-Z、# 排列；</li>
 *     <li>中文组内使用简体中文 Collator 按拼音顺序排列。</li>
 * </ul>
 */
public final class NameSortUtils {

    public static final String SPECIAL_GROUP = "#";

    private static final String LETTER_ORDER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#";

    private NameSortUtils() {
    }

    /**
     * 获取应用名称的分组首字母。
     *
     * @param name 应用名称
     * @return A-Z 或 #
     */
    public static String getFirstLetter(String name) {
        return PinyinUtils.getFirstSortLetter(name);
    }

    /**
     * 构建包含 LetterHeaderItem 和 AppEntryItem 的分组列表。
     */
    public static List<ListItem> buildGroupedAppList(List<AppInfo> apps) {
        List<ListItem> result = new ArrayList<>();

        if (apps == null || apps.isEmpty()) {
            return result;
        }

        Map<String, List<AppInfo>> groupMap = new LinkedHashMap<>();

        for (AppInfo app : apps) {
            if (app == null) {
                continue;
            }

            String letter = normalizeLetter(getFirstLetter(app.getAppName()));
            app.setFirstLetter(letter);

            List<AppInfo> group = groupMap.get(letter);
            if (group == null) {
                group = new ArrayList<>();
                groupMap.put(letter, group);
            }
            group.add(app);
        }

        Comparator<AppInfo> comparator = createAppNameComparator();
        for (List<AppInfo> group : groupMap.values()) {
            Collections.sort(group, comparator);
        }

        for (int i = 0; i < LETTER_ORDER.length(); i++) {
            String letter = String.valueOf(LETTER_ORDER.charAt(i));
            List<AppInfo> group = groupMap.get(letter);

            if (group == null || group.isEmpty()) {
                continue;
            }

            result.add(new LetterHeaderItem(letter));
            for (AppInfo app : group) {
                result.add(new AppEntryItem(app));
            }
        }

        return result;
    }

    /**
     * 仅按应用名称排序，不生成分组标题。
     */
    public static List<AppInfo> sortByName(List<AppInfo> apps) {
        if (apps == null || apps.isEmpty()) {
            return new ArrayList<>();
        }

        List<AppInfo> sorted = new ArrayList<>();
        for (AppInfo app : apps) {
            if (app != null) {
                String letter = normalizeLetter(getFirstLetter(app.getAppName()));
                app.setFirstLetter(letter);
                sorted.add(app);
            }
        }

        Collections.sort(sorted, createAppNameComparator());
        return sorted;
    }

    /**
     * 获取当前应用列表中实际存在的分组字母。
     */
    public static List<String> getExistingLetters(List<AppInfo> apps) {
        List<String> result = new ArrayList<>();

        if (apps == null || apps.isEmpty()) {
            return result;
        }

        boolean[] existing = new boolean[LETTER_ORDER.length()];

        for (AppInfo app : apps) {
            if (app == null) {
                continue;
            }

            String letter = normalizeLetter(getFirstLetter(app.getAppName()));
            app.setFirstLetter(letter);

            int index = LETTER_ORDER.indexOf(letter);
            if (index >= 0) {
                existing[index] = true;
            }
        }

        for (int i = 0; i < LETTER_ORDER.length(); i++) {
            if (existing[i]) {
                result.add(String.valueOf(LETTER_ORDER.charAt(i)));
            }
        }

        return result;
    }

    private static Comparator<AppInfo> createAppNameComparator() {
        final Collator chineseCollator = Collator.getInstance(Locale.CHINA);
        chineseCollator.setStrength(Collator.PRIMARY);

        final Collator localCollator = Collator.getInstance(Locale.getDefault());
        localCollator.setStrength(Collator.PRIMARY);

        return new Comparator<AppInfo>() {
            @Override
            public int compare(AppInfo left, AppInfo right) {
                String leftName = getSafeName(left);
                String rightName = getSafeName(right);

                if (leftName.equals(rightName)) {
                    return 0;
                }

                boolean containsChinese =
                        PinyinUtils.containsChinese(leftName)
                                || PinyinUtils.containsChinese(rightName);

                int result;

                if (containsChinese) {
                    /*
                     * 简体中文 Collator 在 Android 上采用拼音排序。
                     * 中文与同组英文混排时，也使用同一套中文拼音排序规则。
                     */
                    result = chineseCollator.compare(leftName, rightName);
                    if (result != 0) {
                        return result;
                    }
                }

                String leftKey = PinyinUtils.toSortKey(leftName);
                String rightKey = PinyinUtils.toSortKey(rightName);

                result = leftKey.compareTo(rightKey);
                if (result != 0) {
                    return result;
                }

                result = localCollator.compare(leftName, rightName);
                if (result != 0) {
                    return result;
                }

                /*
                 * 最终使用原始字符串保证比较结果稳定，
                 * 防止 Collator PRIMARY 强度把不同名称判断为相同。
                 */
                return leftName.compareTo(rightName);
            }
        };
    }

    private static String getSafeName(AppInfo app) {
        if (app == null || app.getAppName() == null) {
            return "";
        }
        return app.getAppName().trim();
    }

    private static String normalizeLetter(String letter) {
        if (letter == null || letter.isEmpty()) {
            return SPECIAL_GROUP;
        }

        String normalized = letter.substring(0, 1).toUpperCase(Locale.ROOT);
        return LETTER_ORDER.contains(normalized)
                ? normalized
                : SPECIAL_GROUP;
    }
}
