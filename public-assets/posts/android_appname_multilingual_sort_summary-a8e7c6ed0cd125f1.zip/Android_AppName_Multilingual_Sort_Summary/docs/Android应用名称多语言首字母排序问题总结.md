# Android 应用名称多语言首字母排序问题总结与通用工具类

## 1. 文档目的

本文档完整记录 Android 应用列表按照名称首字母分组和排序时出现的中文应用全部进入 `#` 分组的问题，包括：

- 问题与现象；
- 正确需求；
- 根本原因；
- 排查思路；
- 解决方案；
- 实际修改步骤；
- 每项修改的原因；
- 验证方法；
- 常见错误方案；
- 可在其他项目复用的通用工具类。

本文档可以脱离原问题单独阅读，用于以后处理联系人列表、应用列表、文件列表、城市列表等类似的多语言名称排序需求。

---

## 2. 问题描述

应用列表需要按照应用显示名称进行分组和排序，目标规则为：

1. 中文应用按照第一个汉字的拼音首字母分组；
2. 英文应用按照第一个英文字母分组；
3. 带重音的拉丁文字按照去除重音后的字母分组；
4. 其他常见语言尽可能按照对应的拉丁化首字母分组；
5. 数字、符号、Emoji 和无法识别的字符统一进入 `#`；
6. 分组顺序固定为 `A-Z`，最后是 `#`；
7. 同一个字母分组中的名称还需要继续按照符合语言习惯的顺序排列。

原实现只对英文名称有效，中文应用名称无法得到拼音首字母，因此大量中文应用都进入了 `#` 分组。

---

## 3. 问题现象

典型现象如下：

| 应用名称 | 原错误分组 | 正确分组 |
|---|---:|---:|
| 爱奇艺 | `#` | `A` |
| 电话 | `#` | `D` |
| 设置 | `#` | `S` |
| 微信 | `#` | `W` |
| 支付宝 | `#` | `Z` |
| Calendar | `C` | `C` |
| École | `#` 或 `E` 不稳定 | `E` |
| 123 Browser | `#` | `#` |
| ⚙工具 | `#` | `#` |

进一步可能出现以下问题：

- 所有中文应用堆积在列表末尾；
- 右侧字母索引中没有中文应用对应的字母；
- 中文名称虽然被分到同一个字母下，但组内顺序仍不符合拼音顺序；
- 英文大小写导致排序不稳定；
- 带重音文字无法正确归组；
- 空名称、前导空格、Emoji 或符号导致异常；
- 使用 `charAt(0)` 时不能完整处理 Unicode 扩展字符。

---

## 4. 预期结果

修复后的分组规则如下：

```text
A
  爱奇艺
  安全中心
  Amazon

B
  百度
  Browser

D
  电话
  地图

W
  微信
  文件管理

Z
  支付宝
  照相机

#
  123 Browser
  ⚙工具
  😀Demo
```

需要同时满足两层逻辑：

### 4.1 第一层：确定分组字母

负责回答“这个名称属于哪个分组”。

例如：

```text
微信 -> W
电话 -> D
Calendar -> C
École -> E
123 Browser -> #
```

### 4.2 第二层：确定组内顺序

负责回答“同一个分组中的多个名称谁在前、谁在后”。

仅修复第一层并不完整。即使“微信”和“文件管理”都进入 `W`，仍需通过适合中文的比较器决定最终顺序。

---

## 5. 根本原因

## 5.1 Unicode 编码顺序不等于拼音顺序

汉字的 Unicode 编码位置只表示字符编码，不表示拼音。

以下写法不能得到中文拼音：

```java
char first = name.charAt(0);
String letter = String.valueOf(first).toUpperCase();
```

因为“微”仍然是汉字“微”，不会自动转换为 `W`。

使用以下比较也不能得到拼音顺序：

```java
name1.compareTo(name2);
```

`String.compareTo()` 比较的是 UTF-16 编码单元，不是中文发音。

---

## 5.2 使用汉字 Unicode 区间猜测拼音不可靠

部分旧代码会根据汉字编码区间或少量手写范围估算拼音首字母，例如：

```java
if (c >= 某个字符 && c <= 某个字符) {
    return "A";
}
```

这种方式存在根本缺陷：

- 汉字编码不是按照拼音连续排列；
- 同一个拼音首字母对应的汉字散布在不同编码位置；
- 简体字、繁体字和扩展汉字范围不同；
- 多音字无法通过编码区间处理；
- 很容易将无法匹配的汉字统一归入 `#`。

因此，不能通过 Unicode 范围推导真实拼音。

---

## 5.3 只识别 ASCII 英文字母

原逻辑通常只判断：

```java
(c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
```

这样只能处理基础英文字符，以下字符会被漏掉：

```text
É
Å
Ö
Ł
Æ
Ø
```

这些字符需要先通过 Unicode Normalizer 去除组合重音，或通过特殊字符映射转换为基础拉丁字母。

---

## 5.4 分组逻辑和排序逻辑混在一起

常见错误是只使用一个 `Comparator`，希望它同时完成：

- 获取首字母；
- 创建字母分组；
- 决定分组顺序；
- 决定组内顺序。

这会让逻辑难以验证和复用。

正确设计应拆分为：

```text
名称标准化
    ↓
获取分组字母
    ↓
按照 A-Z、# 创建分组
    ↓
每个分组内部排序
    ↓
生成带 Header 的最终列表
```

---

## 5.5 没有明确规定 `#` 分组

若没有统一的兜底规则，数字、符号、空名称和未知文字可能：

- 被丢弃；
- 产生空字符串分组；
- 出现在字母分组中；
- 导致侧边索引定位失败；
- 引发空指针或越界问题。

因此必须把所有无法确定为 `A-Z` 的名称统一规范为 `#`。

---

## 5.6 只处理 `char`，没有处理完整 Unicode Code Point

Java 的一个 `char` 是 UTF-16 代码单元，不一定代表一个完整字符。

以下字符可能由两个 `char` 组成：

- Emoji；
- CJK 扩展区汉字；
- 部分历史文字和特殊字符。

因此读取第一个字符时应使用：

```java
int firstCodePoint = text.codePointAt(0);
```

而不是只使用：

```java
char first = text.charAt(0);
```

---

## 5.7 只使用默认 Locale 的 Collator

设备当前语言不一定是中文。

如果只使用：

```java
Collator.getInstance(Locale.getDefault())
```

当设备语言为英文、越南文或其他语言时，中文排序行为可能不符合拼音顺序。

因此中文名称需要明确使用：

```java
Collator.getInstance(Locale.CHINA)
```

设备当前 Locale 的 Collator 可以作为非中文名称的后备比较器，但不应作为中文拼音排序的唯一依据。

---

## 6. 排查过程与判断思路

## 6.1 先确认错误发生在哪一层

首先分别检查：

1. `AppInfo.firstLetter` 最终保存了什么；
2. 分组 Map 的 Key 是什么；
3. 生成 Header 时是否只遍历了 `A-Z`；
4. Comparator 是否按拼音比较；
5. 未识别字符是否直接进入 `#`。

若中文应用的 `firstLetter` 在进入 Adapter 前已经是 `#`，说明问题发生在“首字母识别层”，而不是 RecyclerView、Adapter 或字母索引控件。

---

## 6.2 使用最小样本验证首字母转换

至少使用以下名称单独调用工具方法：

```text
爱奇艺
电话
设置
微信
支付宝
Calendar
École
123 Browser
⚙工具
```

期望结果：

```text
A
D
S
W
Z
C
E
#
#
```

如果这一层结果错误，不需要继续排查 Adapter。

---

## 6.3 再验证组内排序

使用同一个分组中的多个名称验证：

```text
微信
文件管理
网易云音乐
WiFi
```

即使它们全部进入 `W`，也要确认组内排序不是简单的 Unicode 顺序。

---

## 6.4 最后验证完整列表结构

确认最终列表顺序是：

```text
LetterHeaderItem
AppEntryItem
AppEntryItem
LetterHeaderItem
AppEntryItem
...
```

并检查 `#` 一定出现在所有字母之后。

---

## 7. 最终解决方案

本次解决采用以下结构。

## 7.1 中文首字母：使用 Android ICU AlphabeticIndex

核心代码：

```java
AlphabeticIndex<Object> index =
        new AlphabeticIndex<>(Locale.CHINA);

index.addLabels(Locale.ENGLISH);

AlphabeticIndex.ImmutableIndex<Object> immutableIndex =
        index.buildImmutableIndex();
```

获取中文字符所属桶：

```java
int bucketIndex = immutableIndex.getBucketIndex(chineseCharacter);
AlphabeticIndex.Bucket<Object> bucket =
        immutableIndex.getBucket(bucketIndex);

String label = bucket.getLabel();
```

简体中文索引会将常见汉字按照拼音归入 `A-Z` 桶。

### 为什么使用 AlphabeticIndex

- Android 系统自带；
- 不需要增加第三方依赖；
- API 24 起可用，适合 Android 8.1；
- 比手写 Unicode 区间稳定；
- 适合“获取索引字母”这一需求；
- 初始化一次后可重复使用。

---

## 7.2 中文组内排序：使用 Locale.CHINA Collator

```java
Collator chineseCollator =
        Collator.getInstance(Locale.CHINA);

chineseCollator.setStrength(Collator.PRIMARY);
```

当任一名称包含中文时，优先使用中文 Collator：

```java
if (containsChinese(leftName)
        || containsChinese(rightName)) {
    int result =
            chineseCollator.compare(leftName, rightName);

    if (result != 0) {
        return result;
    }
}
```

### 为什么这么做

`AlphabeticIndex` 负责确定分组字母，但并不负责完整的列表排序。

中文组内仍然需要适合中文语言规则的比较器。把两个职责分开后，逻辑更清晰，也更方便测试。

---

## 7.3 英文和带重音拉丁文字：Unicode 标准化

普通英文直接转换为大写：

```java
if (codePoint >= 'a' && codePoint <= 'z') {
    return Character.toUpperCase((char) codePoint);
}
```

带重音字母先使用 NFD 分解：

```java
String normalized =
        Normalizer.normalize(source, Normalizer.Form.NFD);
```

例如：

```text
É -> E + 组合重音 -> E
Å -> A + 组合圆圈 -> A
```

对于无法通过 NFD 直接拆分的特殊字母，例如 `Æ`、`Ø`、`Ł`、`ß`，使用明确映射。

---

## 7.4 常见非拉丁文字：转换为拉丁首字母

通用工具类额外处理了常见：

- 希腊文；
- 西里尔文；
- 日文假名；
- 韩文音节；
- 阿拉伯文；
- 希伯来文。

这部分用于实现“国外其他语言也类似”的需求。

无法可靠转换的字符仍进入 `#`，而不是猜测错误的字母。

---

## 7.5 数字、符号和未知字符：统一进入 `#`

```java
if (Character.isDigit(firstCodePoint)) {
    return "#";
}
```

无法转换的文字最终也返回：

```java
return "#";
```

### 为什么数字不进入首个数字分组

当前列表索引定义为：

```text
A-Z、#
```

如果额外创建 `0-9` 分组，会影响现有右侧索引、Header 类型和列表定位逻辑。统一进入 `#` 可以保持改动最小。

---

## 7.6 固定分组顺序

不能直接依赖 HashMap 的遍历顺序。

应明确规定：

```java
private static final String LETTER_ORDER =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ#";
```

最终生成列表时按照这个字符串顺序读取分组。

### 为什么使用 LinkedHashMap

`LinkedHashMap` 可以保持插入顺序。

工具类先按照 `A-Z、#` 固定顺序重新插入实际存在的数据分组，调用者遍历 Map 时即可得到稳定顺序。

---

## 7.7 保证比较结果稳定

Collator 使用 `PRIMARY` 强度时，部分不同字符串可能被视为相同。

因此比较器最后增加：

```java
return leftName.compareTo(rightName);
```

这不是为了按 Unicode 进行主要排序，而是作为最后的稳定兜底，确保 Comparator 满足排序算法要求。

---

## 8. 为什么没有使用其他方案

## 8.1 不使用手写汉字范围表

原因：

- 不准确；
- 数据量大；
- 维护成本高；
- 多音字无法解决；
- 扩展汉字无法覆盖；
- 极易再次出现中文进入 `#` 的问题。

---

## 8.2 不只使用 String.compareTo

原因：

- 它按照 UTF-16 编码值比较；
- 不理解拼音；
- 不理解重音；
- 不理解语言环境。

---

## 8.3 不只使用 Collator 完成所有工作

Collator 适合比较两个字符串，但不直接返回 `A-Z` 分组字母。

因此仍需要 `AlphabeticIndex` 或其他首字母转换逻辑完成分组。

---

## 8.4 不使用 android.icu.text.Transliterator

`Transliterator` 可以做更完整的文字转写，但公开 Android API 的兼容范围晚于本项目需要覆盖的 Android 8.1。

为了保证 Android 8.1 可运行，本次不使用它。

---

## 8.5 不引入第三方拼音库

第三方库可以提供完整拼音，但会带来：

- 新依赖；
- APK 体积增加；
- 版本兼容成本；
- 系统应用构建环境接入成本；
- 混淆与许可证检查；
- AOSP 预置应用可能无法直接访问外部 Maven。

本次需求只需要首字母分组，Android ICU 已足够，因此不增加第三方依赖。

---

## 9. 实际修改范围

当前项目只需要替换：

```text
app/src/main/java/com/sgtc/privacymanager/utils/PinyinUtils.java
app/src/main/java/com/sgtc/privacymanager/utils/NameSortUtils.java
```

未修改：

- ViewModel；
- Repository；
- Adapter；
- RecyclerView；
- SideBar；
- AppInfo 数据模型；
- Gradle 配置；
- Manifest；
- 资源文件。

### 为什么只改两个工具类

问题发生在“名称分组和排序工具层”。

上层列表加载、数据绑定和显示逻辑本身没有必要修改。限制修改范围可以降低回归风险，也符合最小化修改原则。

---

## 10. 实际操作步骤

## 10.1 备份原文件

```bash
cp app/src/main/java/com/sgtc/privacymanager/utils/PinyinUtils.java \
   app/src/main/java/com/sgtc/privacymanager/utils/PinyinUtils.java.bak

cp app/src/main/java/com/sgtc/privacymanager/utils/NameSortUtils.java \
   app/src/main/java/com/sgtc/privacymanager/utils/NameSortUtils.java.bak
```

---

## 10.2 覆盖修复文件

将压缩包中的以下文件复制到项目对应路径：

```text
current_project/app/src/main/java/com/sgtc/privacymanager/utils/PinyinUtils.java

current_project/app/src/main/java/com/sgtc/privacymanager/utils/NameSortUtils.java
```

---

## 10.3 清理旧构建缓存

Gradle 工程：

```bash
./gradlew clean
```

Windows：

```bat
gradlew.bat clean
```

AOSP 工程可根据模块构建方式清理对应中间产物，避免旧 dex 或旧 class 被继续使用。

---

## 10.4 重新编译安装

Gradle 示例：

```bash
./gradlew assembleDebug
```

或使用项目原有 release 构建命令。

---

## 10.5 清理应用旧数据后验证

如果应用曾缓存完整列表或首字母字段，需要清理应用数据：

```bash
adb shell pm clear com.sgtc.privacymanager
```

随后重新启动应用，让列表重新读取和计算首字母。

---

## 11. 验证用例

## 11.1 首字母验证

| 输入 | 期望 |
|---|---:|
| `爱奇艺` | `A` |
| `百度` | `B` |
| `电话` | `D` |
| `设置` | `S` |
| `微信` | `W` |
| `支付宝` | `Z` |
| `Calendar` | `C` |
| `calendar` | `C` |
| `École` | `E` |
| `Österreich` | `O` |
| `123 Browser` | `#` |
| `⚙工具` | `#` |
| 空字符串 | `#` |
| `null` | `#` |

---

## 11.2 列表顺序验证

准备测试数据：

```text
微信
Calendar
支付宝
电话
123 Browser
爱奇艺
百度
École
```

期望 Header 顺序：

```text
A
B
C
D
E
W
Z
#
```

---

## 11.3 边界验证

必须检查：

- 名称前面有空格；
- 名称为 `null`；
- 名称为空字符串；
- 名称以数字开头；
- 名称以 Emoji 开头；
- 名称包含繁体中文；
- 名称包含 Unicode 扩展汉字；
- 同一分组中有中文和英文；
- 切换系统语言后列表仍不崩溃；
- 多次刷新后排序结果保持一致。

---

## 12. 复用工具类说明

通用工具类文件：

```text
app/src/main/java/com/sgtc/common/utils/
└── MultilingualNameSortUtils.java
```

它不依赖当前项目的以下类：

```text
AppInfo
ListItem
LetterHeaderItem
AppEntryItem
Adapter
ViewModel
```

因此可复制到其他 Android 项目使用。

使用时只需要根据目标项目修改第一行包名：

```java
package com.sgtc.common.utils;
```

---

## 13. 通用工具类使用示例

## 13.1 获取单个名称的分组字母

```java
String letter =
        MultilingualNameSortUtils.getGroupLetter("微信");

// 结果：W
```

---

## 13.2 对字符串列表排序

```java
List<String> sorted =
        MultilingualNameSortUtils.sortNames(names);
```

此方法返回新列表，不修改原列表。

---

## 13.3 对字符串列表分组

```java
Map<String, List<String>> groups =
        MultilingualNameSortUtils.groupNames(names);

for (Map.Entry<String, List<String>> entry
        : groups.entrySet()) {

    String letter = entry.getKey();
    List<String> groupNames = entry.getValue();
}
```

Map 的遍历顺序固定为：

```text
A-Z、#
```

只会返回实际存在数据的分组。

---

## 13.4 对 AppInfo 列表排序

为兼容不使用 Lambda 的旧项目，可使用匿名内部类：

```java
List<AppInfo> sortedApps =
        MultilingualNameSortUtils.sortItems(
                apps,
                new MultilingualNameSortUtils.NameProvider<AppInfo>() {
                    @Override
                    public String getName(AppInfo item) {
                        return item == null
                                ? ""
                                : item.getAppName();
                    }
                }
        );
```

---

## 13.5 对 AppInfo 列表分组

```java
Map<String, List<AppInfo>> groups =
        MultilingualNameSortUtils.groupItems(
                apps,
                new MultilingualNameSortUtils.NameProvider<AppInfo>() {
                    @Override
                    public String getName(AppInfo item) {
                        return item == null
                                ? ""
                                : item.getAppName();
                    }
                }
        );
```

生成当前项目需要的 Header 列表：

```java
List<ListItem> result = new ArrayList<>();

for (Map.Entry<String, List<AppInfo>> entry
        : groups.entrySet()) {

    result.add(new LetterHeaderItem(entry.getKey()));

    for (AppInfo appInfo : entry.getValue()) {
        appInfo.setFirstLetter(entry.getKey());
        result.add(new AppEntryItem(appInfo));
    }
}
```

---

## 14. 通用工具类完整代码

```java
package com.sgtc.common.utils;

import android.icu.text.AlphabeticIndex;

import java.text.Collator;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 通用多语言名称首字母分组与排序工具。
 *
 * <p>兼容 Android 8.1（API 27），不依赖第三方拼音库。</p>
 *
 * <p>处理规则：</p>
 * <ul>
 *     <li>中文：使用 Android ICU 的简体中文拼音索引获取 A-Z 首字母；</li>
 *     <li>英文：直接使用首字母；</li>
 *     <li>带重音的拉丁文字：去除重音后归入 A-Z；</li>
 *     <li>常见希腊文、俄文、日文假名、韩文、阿拉伯文和希伯来文：
 *         转换为对应的拉丁首字母；</li>
 *     <li>数字、符号、Emoji 或无法识别的文字：归入 #。</li>
 * </ul>
 */
public final class MultilingualNameSortUtils {

    public static final String SPECIAL_GROUP = "#";
    public static final String LETTER_ORDER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#";

    /**
     * AlphabeticIndex 从 API 24 开始提供。
     * 使用 zh_CN 索引时，简体中文按拼音 A-Z 分桶。
     * ImmutableIndex 是线程安全的，可供后台线程和主线程共同读取。
     */
    private static final AlphabeticIndex.ImmutableIndex<Object> CHINESE_INDEX =
            createChineseIndex();

    private MultilingualNameSortUtils() {
    }

    private static AlphabeticIndex.ImmutableIndex<Object> createChineseIndex() {
        AlphabeticIndex<Object> index = new AlphabeticIndex<>(Locale.CHINA);
        index.addLabels(Locale.ENGLISH);
        return index.buildImmutableIndex();
    }

    /**
     * 获取应用名称的分组首字母。
     *
     * @param text 应用名称
     * @return A-Z 或 #
     */
    public static String getFirstSortLetter(String text) {
        if (text == null) {
            return SPECIAL_GROUP;
        }

        String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return SPECIAL_GROUP;
        }

        int firstCodePoint = trimmed.codePointAt(0);

        if (Character.isDigit(firstCodePoint)) {
            return SPECIAL_GROUP;
        }

        char latinLetter = foldLatinToAsciiInitial(firstCodePoint);
        if (latinLetter != 0) {
            return String.valueOf(latinLetter);
        }

        if (isChineseCodePoint(firstCodePoint)) {
            char chineseLetter = getChineseBucketLetter(
                    new String(Character.toChars(firstCodePoint))
            );
            return chineseLetter == 0
                    ? SPECIAL_GROUP
                    : String.valueOf(chineseLetter);
        }

        char scriptLetter = mapNonLatinScriptInitial(firstCodePoint);
        return scriptLetter == 0
                ? SPECIAL_GROUP
                : String.valueOf(scriptLetter);
    }

    /**
     * 获取单个汉字的拼音首字母。
     *
     * @param c 汉字
     * @return A-Z；不是汉字或无法识别时返回 null
     */
    public static Character getFirstPinyinLetter(char c) {
        if (!isChineseCodePoint(c)) {
            return null;
        }

        char letter = getChineseBucketLetter(String.valueOf(c));
        return letter == 0 ? null : letter;
    }

    /**
     * 生成用于非中文名称比较的稳定排序键。
     *
     * <p>中文名称的最终组内顺序由 NameSortUtils 中的中文 Collator 决定；
     * 此方法主要负责英文、带重音拉丁文字及常见非拉丁文字。</p>
     */
    public static String toSortKey(String text) {
        if (text == null) {
            return "";
        }

        String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return "";
        }

        StringBuilder result = new StringBuilder(trimmed.length());
        boolean previousWasSpace = false;

        for (int offset = 0; offset < trimmed.length(); ) {
            int codePoint = trimmed.codePointAt(offset);
            offset += Character.charCount(codePoint);

            if (Character.isWhitespace(codePoint)) {
                if (!previousWasSpace && result.length() > 0) {
                    result.append(' ');
                }
                previousWasSpace = true;
                continue;
            }

            previousWasSpace = false;

            if (Character.isDigit(codePoint)) {
                result.appendCodePoint(codePoint);
                continue;
            }

            char latinLetter = foldLatinToAsciiInitial(codePoint);
            if (latinLetter != 0) {
                result.append(Character.toLowerCase(latinLetter));
                continue;
            }

            if (isChineseCodePoint(codePoint)) {
                char chineseLetter = getChineseBucketLetter(
                        new String(Character.toChars(codePoint))
                );
                if (chineseLetter != 0) {
                    result.append(Character.toLowerCase(chineseLetter));
                } else {
                    result.appendCodePoint(codePoint);
                }
                continue;
            }

            char scriptLetter = mapNonLatinScriptInitial(codePoint);
            if (scriptLetter != 0) {
                result.append(Character.toLowerCase(scriptLetter));
            } else {
                result.appendCodePoint(Character.toLowerCase(codePoint));
            }
        }

        return result.toString().trim();
    }

    /**
     * 判断名称中是否包含中文字符。
     */
    public static boolean containsChinese(String text) {
        if (text == null || text.isEmpty()) {
            return false;
        }

        for (int offset = 0; offset < text.length(); ) {
            int codePoint = text.codePointAt(offset);
            if (isChineseCodePoint(codePoint)) {
                return true;
            }
            offset += Character.charCount(codePoint);
        }
        return false;
    }

    /**
     * 保留原工具类公开接口。
     */
    public static boolean isEnglishLetter(char c) {
        return (c >= 'a' && c <= 'z')
                || (c >= 'A' && c <= 'Z');
    }

    /**
     * 保留原工具类公开接口。
     */
    public static boolean isDigit(char c) {
        return Character.isDigit(c);
    }

    /**
     * 保留原工具类公开接口。
     *
     * <p>返回用于兼容旧代码的拼音首字母小写形式。</p>
     */
    public static String getPinyinString(char c) {
        Character letter = getFirstPinyinLetter(c);
        return letter == null
                ? ""
                : String.valueOf(Character.toLowerCase(letter));
    }


    /**
     * 从任意业务对象中读取显示名称。
     *
     * @param <T> 业务对象类型
     */
    public interface NameProvider<T> {

        /**
         * 返回用于排序和分组的显示名称。
         */
        String getName(T item);
    }

    /**
     * 获取名称分组字母。
     *
     * @param name 显示名称
     * @return A-Z 或 #
     */
    public static String getGroupLetter(String name) {
        return normalizeGroupLetter(getFirstSortLetter(name));
    }

    /**
     * 返回可直接用于 Collections.sort 的名称比较器。
     *
     * <p>比较顺序：</p>
     * <ol>
     *     <li>A-Z、# 分组顺序；</li>
     *     <li>中文名称使用简体中文 Collator；</li>
     *     <li>使用标准化后的拉丁排序键；</li>
     *     <li>使用设备当前 Locale 的 Collator；</li>
     *     <li>使用原始字符串保证结果稳定。</li>
     * </ol>
     */
    public static Comparator<String> getNameComparator() {
        final Collator chineseCollator = Collator.getInstance(Locale.CHINA);
        chineseCollator.setStrength(Collator.PRIMARY);

        final Collator localCollator = Collator.getInstance(Locale.getDefault());
        localCollator.setStrength(Collator.PRIMARY);

        return new Comparator<String>() {
            @Override
            public int compare(String left, String right) {
                String leftName = safeName(left);
                String rightName = safeName(right);

                if (leftName.equals(rightName)) {
                    return 0;
                }

                int leftGroupIndex = getGroupIndex(getGroupLetter(leftName));
                int rightGroupIndex = getGroupIndex(getGroupLetter(rightName));

                if (leftGroupIndex != rightGroupIndex) {
                    return leftGroupIndex < rightGroupIndex ? -1 : 1;
                }

                if (containsChinese(leftName) || containsChinese(rightName)) {
                    int result = chineseCollator.compare(leftName, rightName);
                    if (result != 0) {
                        return result;
                    }
                }

                String leftKey = toSortKey(leftName);
                String rightKey = toSortKey(rightName);

                int result = leftKey.compareTo(rightKey);
                if (result != 0) {
                    return result;
                }

                result = localCollator.compare(leftName, rightName);
                if (result != 0) {
                    return result;
                }

                return leftName.compareTo(rightName);
            }
        };
    }

    /**
     * 返回任意业务对象的比较器。
     */
    public static <T> Comparator<T> getItemComparator(
            final NameProvider<T> nameProvider) {

        if (nameProvider == null) {
            throw new IllegalArgumentException("nameProvider == null");
        }

        final Comparator<String> nameComparator = getNameComparator();

        return new Comparator<T>() {
            @Override
            public int compare(T left, T right) {
                String leftName = left == null ? "" : nameProvider.getName(left);
                String rightName = right == null ? "" : nameProvider.getName(right);
                return nameComparator.compare(leftName, rightName);
            }
        };
    }

    /**
     * 对名称列表排序。
     *
     * <p>不会修改传入列表，返回新的 ArrayList。</p>
     */
    public static List<String> sortNames(List<String> names) {
        List<String> result = names == null
                ? new ArrayList<String>()
                : new ArrayList<>(names);

        Collections.sort(result, getNameComparator());
        return result;
    }

    /**
     * 对任意业务对象列表排序。
     *
     * <p>不会修改传入列表，返回新的 ArrayList。</p>
     */
    public static <T> List<T> sortItems(
            List<T> items,
            NameProvider<T> nameProvider) {

        List<T> result = items == null
                ? new ArrayList<T>()
                : new ArrayList<>(items);

        Collections.sort(result, getItemComparator(nameProvider));
        return result;
    }

    /**
     * 按 A-Z、# 对名称列表分组，并对每个分组内部排序。
     *
     * <p>返回 LinkedHashMap，遍历顺序固定为 A-Z、#。</p>
     */
    public static Map<String, List<String>> groupNames(List<String> names) {
        return groupItems(
                names,
                new NameProvider<String>() {
                    @Override
                    public String getName(String item) {
                        return item;
                    }
                }
        );
    }

    /**
     * 按 A-Z、# 对任意业务对象分组，并对每个分组内部排序。
     *
     * <p>返回结果只包含实际存在数据的分组。</p>
     */
    public static <T> Map<String, List<T>> groupItems(
            List<T> items,
            NameProvider<T> nameProvider) {

        if (nameProvider == null) {
            throw new IllegalArgumentException("nameProvider == null");
        }

        Map<String, List<T>> temporaryGroups = new LinkedHashMap<>();

        if (items != null) {
            for (T item : items) {
                String name = item == null ? "" : nameProvider.getName(item);
                String groupLetter = getGroupLetter(name);

                List<T> group = temporaryGroups.get(groupLetter);
                if (group == null) {
                    group = new ArrayList<>();
                    temporaryGroups.put(groupLetter, group);
                }
                group.add(item);
            }
        }

        Comparator<T> comparator = getItemComparator(nameProvider);
        for (List<T> group : temporaryGroups.values()) {
            Collections.sort(group, comparator);
        }

        Map<String, List<T>> orderedGroups = new LinkedHashMap<>();

        for (int i = 0; i < LETTER_ORDER.length(); i++) {
            String letter = String.valueOf(LETTER_ORDER.charAt(i));
            List<T> group = temporaryGroups.get(letter);

            if (group != null && !group.isEmpty()) {
                orderedGroups.put(letter, group);
            }
        }

        return orderedGroups;
    }

    /**
     * 获取当前数据中实际存在的分组字母。
     */
    public static <T> List<String> getExistingGroupLetters(
            List<T> items,
            NameProvider<T> nameProvider) {

        Map<String, List<T>> groups = groupItems(items, nameProvider);
        return new ArrayList<>(groups.keySet());
    }

    private static String normalizeGroupLetter(String letter) {
        if (letter == null || letter.isEmpty()) {
            return SPECIAL_GROUP;
        }

        String normalized = letter.substring(0, 1).toUpperCase(Locale.ROOT);
        return LETTER_ORDER.contains(normalized)
                ? normalized
                : SPECIAL_GROUP;
    }

    private static int getGroupIndex(String letter) {
        int index = LETTER_ORDER.indexOf(normalizeGroupLetter(letter));
        return index >= 0 ? index : LETTER_ORDER.length() - 1;
    }

    private static String safeName(String name) {
        return name == null ? "" : name.trim();
    }

    private static char getChineseBucketLetter(String chineseCharacter) {
        try {
            int bucketIndex = CHINESE_INDEX.getBucketIndex(chineseCharacter);
            AlphabeticIndex.Bucket<Object> bucket =
                    CHINESE_INDEX.getBucket(bucketIndex);

            if (bucket == null) {
                return 0;
            }

            return extractAsciiLetter(bucket.getLabel());
        } catch (RuntimeException ignored) {
            // ICU 数据异常时返回 0，由调用方归入 #，避免列表加载崩溃。
            return 0;
        }
    }

    private static char foldLatinToAsciiInitial(int codePoint) {
        if (codePoint >= 'a' && codePoint <= 'z') {
            return Character.toUpperCase((char) codePoint);
        }
        if (codePoint >= 'A' && codePoint <= 'Z') {
            return (char) codePoint;
        }

        char specialLetter = mapSpecialLatinLetter(codePoint);
        if (specialLetter != 0) {
            return specialLetter;
        }

        String source = new String(Character.toChars(codePoint));
        String normalized = Normalizer.normalize(source, Normalizer.Form.NFD);
        return extractAsciiLetter(normalized);
    }

    private static char extractAsciiLetter(String text) {
        if (text == null || text.isEmpty()) {
            return 0;
        }

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= 'a' && c <= 'z') {
                return Character.toUpperCase(c);
            }
            if (c >= 'A' && c <= 'Z') {
                return c;
            }
        }
        return 0;
    }

    private static char mapSpecialLatinLetter(int codePoint) {
        switch (codePoint) {
            case '\u00C6': // Æ
            case '\u00E6': // æ
                return 'A';

            case '\u0152': // Œ
            case '\u0153': // œ
            case '\u00D8': // Ø
            case '\u00F8': // ø
                return 'O';

            case '\u00D0': // Ð
            case '\u00F0': // ð
            case '\u0110': // Đ
            case '\u0111': // đ
                return 'D';

            case '\u00DE': // Þ
            case '\u00FE': // þ
                return 'T';

            case '\u0141': // Ł
            case '\u0142': // ł
                return 'L';

            case '\u00DF': // ß
                return 'S';

            case '\u0126': // Ħ
            case '\u0127': // ħ
                return 'H';

            case '\u0131': // ı
                return 'I';

            case '\u014A': // Ŋ
            case '\u014B': // ŋ
                return 'N';

            case '\u018F': // Ə
            case '\u0259': // ə
                return 'E';

            default:
                return 0;
        }
    }

    private static boolean isChineseCodePoint(int codePoint) {
        return (codePoint >= 0x3400 && codePoint <= 0x4DBF)
                || (codePoint >= 0x4E00 && codePoint <= 0x9FFF)
                || (codePoint >= 0xF900 && codePoint <= 0xFAFF)
                || (codePoint >= 0x20000 && codePoint <= 0x2A6DF)
                || (codePoint >= 0x2A700 && codePoint <= 0x2B73F)
                || (codePoint >= 0x2B740 && codePoint <= 0x2B81F)
                || (codePoint >= 0x2B820 && codePoint <= 0x2CEAF)
                || (codePoint >= 0x2CEB0 && codePoint <= 0x2EBEF)
                || (codePoint >= 0x2F800 && codePoint <= 0x2FA1F)
                || (codePoint >= 0x30000 && codePoint <= 0x3134F)
                || (codePoint >= 0x31350 && codePoint <= 0x323AF);
    }

    private static char mapNonLatinScriptInitial(int codePoint) {
        char greek = mapGreekInitial(codePoint);
        if (greek != 0) {
            return greek;
        }

        char cyrillic = mapCyrillicInitial(codePoint);
        if (cyrillic != 0) {
            return cyrillic;
        }

        char japanese = mapJapaneseInitial(codePoint);
        if (japanese != 0) {
            return japanese;
        }

        char korean = mapKoreanInitial(codePoint);
        if (korean != 0) {
            return korean;
        }

        char arabic = mapArabicInitial(codePoint);
        if (arabic != 0) {
            return arabic;
        }

        return mapHebrewInitial(codePoint);
    }

    private static char mapGreekInitial(int codePoint) {
        int upper = Character.toUpperCase(codePoint);
        switch (upper) {
            case 0x0391: return 'A'; // Α
            case 0x0392: return 'B'; // Β
            case 0x0393: return 'G'; // Γ
            case 0x0394: return 'D'; // Δ
            case 0x0395: return 'E'; // Ε
            case 0x0396: return 'Z'; // Ζ
            case 0x0397: return 'E'; // Η
            case 0x0398: return 'T'; // Θ
            case 0x0399: return 'I'; // Ι
            case 0x039A: return 'K'; // Κ
            case 0x039B: return 'L'; // Λ
            case 0x039C: return 'M'; // Μ
            case 0x039D: return 'N'; // Ν
            case 0x039E: return 'X'; // Ξ
            case 0x039F: return 'O'; // Ο
            case 0x03A0: return 'P'; // Π
            case 0x03A1: return 'R'; // Ρ
            case 0x03A3: return 'S'; // Σ
            case 0x03A4: return 'T'; // Τ
            case 0x03A5: return 'Y'; // Υ
            case 0x03A6: return 'F'; // Φ
            case 0x03A7: return 'C'; // Χ
            case 0x03A8: return 'P'; // Ψ
            case 0x03A9: return 'O'; // Ω
            default: return 0;
        }
    }

    private static char mapCyrillicInitial(int codePoint) {
        int upper = Character.toUpperCase(codePoint);
        switch (upper) {
            case 0x0410: return 'A'; // А
            case 0x0411: return 'B'; // Б
            case 0x0412: return 'V'; // В
            case 0x0413:
            case 0x0490: return 'G'; // Г, Ґ
            case 0x0414: return 'D'; // Д
            case 0x0415:
            case 0x0401:
            case 0x0404: return 'E'; // Е, Ё, Є
            case 0x0416: return 'Z'; // Ж
            case 0x0417: return 'Z'; // З
            case 0x0418:
            case 0x0419:
            case 0x0406:
            case 0x0407: return 'I'; // И, Й, І, Ї
            case 0x041A: return 'K'; // К
            case 0x041B: return 'L'; // Л
            case 0x041C: return 'M'; // М
            case 0x041D: return 'N'; // Н
            case 0x041E: return 'O'; // О
            case 0x041F: return 'P'; // П
            case 0x0420: return 'R'; // Р
            case 0x0421: return 'S'; // С
            case 0x0422: return 'T'; // Т
            case 0x0423: return 'U'; // У
            case 0x0424: return 'F'; // Ф
            case 0x0425: return 'H'; // Х
            case 0x0426: return 'C'; // Ц
            case 0x0427:
            case 0x040B: return 'C'; // Ч, Ћ
            case 0x0428:
            case 0x0429: return 'S'; // Ш, Щ
            case 0x042B: return 'Y'; // Ы
            case 0x042D: return 'E'; // Э
            case 0x042E: return 'Y'; // Ю
            case 0x042F: return 'Y'; // Я
            case 0x0402: return 'D'; // Ђ
            case 0x0405: return 'S'; // Ѕ
            case 0x0408: return 'J'; // Ј
            case 0x0409: return 'L'; // Љ
            case 0x040A: return 'N'; // Њ
            case 0x040F: return 'D'; // Џ
            default: return 0;
        }
    }

    private static char mapJapaneseInitial(int codePoint) {
        int hiragana = codePoint;

        // 片假名转换到对应平假名范围。
        if (codePoint >= 0x30A1 && codePoint <= 0x30F6) {
            hiragana = codePoint - 0x60;
        }

        switch (hiragana) {
            // A 行
            case 0x3041:
            case 0x3042:
            case 0x3043:
            case 0x3044:
            case 0x3045:
            case 0x3046:
            case 0x3047:
            case 0x3048:
            case 0x3049:
            case 0x304A:
                return 'A';

            // K / G 行
            case 0x304B:
            case 0x304D:
            case 0x304F:
            case 0x3051:
            case 0x3053:
                return 'K';
            case 0x304C:
            case 0x304E:
            case 0x3050:
            case 0x3052:
            case 0x3054:
                return 'G';

            // S / Z 行
            case 0x3055:
            case 0x3057:
            case 0x3059:
            case 0x305B:
            case 0x305D:
                return 'S';
            case 0x3056:
            case 0x3058:
            case 0x305A:
            case 0x305C:
            case 0x305E:
                return 'Z';

            // T / D 行
            case 0x305F:
            case 0x3061:
            case 0x3063:
            case 0x3064:
            case 0x3066:
            case 0x3068:
                return 'T';
            case 0x3060:
            case 0x3062:
            case 0x3065:
            case 0x3067:
            case 0x3069:
                return 'D';

            // N 行
            case 0x306A:
            case 0x306B:
            case 0x306C:
            case 0x306D:
            case 0x306E:
            case 0x3093:
                return 'N';

            // H / B / P 行
            case 0x306F:
            case 0x3072:
            case 0x3075:
            case 0x3078:
            case 0x307B:
                return 'H';
            case 0x3070:
            case 0x3073:
            case 0x3076:
            case 0x3079:
            case 0x307C:
                return 'B';
            case 0x3071:
            case 0x3074:
            case 0x3077:
            case 0x307A:
            case 0x307D:
                return 'P';

            // M 行
            case 0x307E:
            case 0x307F:
            case 0x3080:
            case 0x3081:
            case 0x3082:
                return 'M';

            // Y 行
            case 0x3083:
            case 0x3084:
            case 0x3085:
            case 0x3086:
            case 0x3087:
            case 0x3088:
                return 'Y';

            // R 行
            case 0x3089:
            case 0x308A:
            case 0x308B:
            case 0x308C:
            case 0x308D:
                return 'R';

            // W 行
            case 0x308E:
            case 0x308F:
            case 0x3090:
            case 0x3091:
            case 0x3092:
                return 'W';

            case 0x3094: // ゔ
                return 'V';

            default:
                return 0;
        }
    }

    private static char mapKoreanInitial(int codePoint) {
        if (codePoint < 0xAC00 || codePoint > 0xD7A3) {
            return 0;
        }

        int syllableIndex = codePoint - 0xAC00;
        int leadingConsonantIndex = syllableIndex / 588;
        int vowelIndex = (syllableIndex % 588) / 28;

        switch (leadingConsonantIndex) {
            case 0: return 'G';  // ㄱ
            case 1: return 'K';  // ㄲ
            case 2: return 'N';  // ㄴ
            case 3: return 'D';  // ㄷ
            case 4: return 'T';  // ㄸ
            case 5: return 'R';  // ㄹ
            case 6: return 'M';  // ㅁ
            case 7: return 'B';  // ㅂ
            case 8: return 'P';  // ㅃ
            case 9:
            case 10: return 'S'; // ㅅ, ㅆ
            case 11: return mapKoreanVowelInitial(vowelIndex); // ㅇ
            case 12:
            case 13: return 'J'; // ㅈ, ㅉ
            case 14: return 'C'; // ㅊ
            case 15: return 'K'; // ㅋ
            case 16: return 'T'; // ㅌ
            case 17: return 'P'; // ㅍ
            case 18: return 'H'; // ㅎ
            default: return 0;
        }
    }

    private static char mapKoreanVowelInitial(int vowelIndex) {
        switch (vowelIndex) {
            case 0:
            case 1:
                return 'A';
            case 2:
            case 3:
            case 6:
            case 7:
            case 12:
            case 17:
                return 'Y';
            case 4:
            case 5:
            case 18:
                return 'E';
            case 8:
            case 11:
                return 'O';
            case 9:
            case 10:
            case 14:
            case 15:
            case 16:
                return 'W';
            case 13:
                return 'U';
            case 19:
                return 'U';
            case 20:
                return 'I';
            default:
                return 0;
        }
    }

    private static char mapArabicInitial(int codePoint) {
        switch (codePoint) {
            case 0x0627:
            case 0x0622:
            case 0x0623:
            case 0x0625:
            case 0x0671:
            case 0x0639:
                return 'A';
            case 0x0628: return 'B';
            case 0x062A:
            case 0x062B:
            case 0x0637:
                return 'T';
            case 0x062C: return 'J';
            case 0x062D:
            case 0x0647:
                return 'H';
            case 0x062E: return 'K';
            case 0x062F:
            case 0x0630:
            case 0x0636:
                return 'D';
            case 0x0631: return 'R';
            case 0x0632:
            case 0x0698:
            case 0x0638:
                return 'Z';
            case 0x0633:
            case 0x0634:
            case 0x0635:
                return 'S';
            case 0x063A:
            case 0x06AF:
                return 'G';
            case 0x0641: return 'F';
            case 0x0642: return 'Q';
            case 0x0643: return 'K';
            case 0x0644: return 'L';
            case 0x0645: return 'M';
            case 0x0646: return 'N';
            case 0x0648: return 'W';
            case 0x064A:
            case 0x0649:
                return 'Y';
            case 0x067E: return 'P';
            case 0x0686: return 'C';
            default: return 0;
        }
    }

    private static char mapHebrewInitial(int codePoint) {
        switch (codePoint) {
            case 0x05D0:
            case 0x05E2:
                return 'A';
            case 0x05D1: return 'B';
            case 0x05D2: return 'G';
            case 0x05D3: return 'D';
            case 0x05D4:
            case 0x05D7:
                return 'H';
            case 0x05D5: return 'V';
            case 0x05D6: return 'Z';
            case 0x05D8:
            case 0x05EA:
                return 'T';
            case 0x05D9: return 'Y';
            case 0x05DA:
            case 0x05DB:
            case 0x05E7:
                return 'K';
            case 0x05DC: return 'L';
            case 0x05DD:
            case 0x05DE:
                return 'M';
            case 0x05DF:
            case 0x05E0:
                return 'N';
            case 0x05E1:
            case 0x05E9:
                return 'S';
            case 0x05E3:
            case 0x05E4:
                return 'P';
            case 0x05E5:
            case 0x05E6:
                return 'C';
            case 0x05E8: return 'R';
            default: return 0;
        }
    }
}

```

---

## 15. 已知边界与设计取舍

## 15.1 多音字

中文多音字需要结合词语上下文才能确定真实读音。

`AlphabeticIndex` 和 `Collator` 使用系统语言数据处理，能满足常见应用名称排序，但不能保证所有多音字都符合用户主观预期。

例如某些姓氏、品牌名或特殊词语可能使用非常用读音。

若产品要求对指定品牌做强制排序，可在调用工具前增加业务别名表：

```text
应用包名 -> 指定排序名称
```

不要直接修改通用拼音算法。

---

## 15.2 日文汉字

汉字在 Unicode 中属于 Han Script。

通用工具会优先把 Han 字符按中文拼音索引处理。日文假名可做罗马字首字母映射，但日文汉字的正确读音依赖日语词汇和上下文，不能仅凭一个字符可靠确定。

若目标项目主要面向日语市场，应针对日语 Locale 另行设计名称读取和排序策略。

---

## 15.3 非拉丁文字映射是实用映射，不是完整语言学转写

希腊文、俄文、韩文、阿拉伯文等映射主要用于得到稳定的 `A-Z` 分组字母。

它不等同于完整的姓名转写、搜索索引或自然语言处理系统。

---

## 15.4 应用名称可能随系统语言变化

Android 的应用标签可能根据系统 Locale 返回不同语言。

切换系统语言后，应重新读取 `ApplicationInfo.loadLabel()` 并重新计算分组，不应永久缓存旧语言的首字母。

---

## 16. 后续开发检查清单

以后遇到同类问题时，按以下顺序检查：

- [ ] 是否读取了正确的本地化显示名称；
- [ ] 是否在计算前执行了 `trim()`；
- [ ] 是否使用 Code Point，而不是只使用 `charAt(0)`；
- [ ] 中文是否通过真正的语言索引转换；
- [ ] 英文大小写是否统一；
- [ ] 重音字符是否做了标准化；
- [ ] 未知字符是否统一进入 `#`；
- [ ] 分组顺序是否明确固定为 `A-Z、#`；
- [ ] 组内是否使用合适的 Collator；
- [ ] Comparator 是否有稳定的最终兜底；
- [ ] 是否错误依赖 HashMap 遍历顺序；
- [ ] 是否清除了旧缓存并重新加载列表；
- [ ] 是否测试了中英文混排；
- [ ] 是否测试了空名称、数字、符号和 Emoji；
- [ ] 是否确认使用的 Android API 与 minSdk 兼容。

---

## 17. 最终总结

本问题不是 Adapter、RecyclerView 或 Header 显示错误，而是名称排序工具只正确识别了英文，未真正把中文汉字转换为拼音首字母。

完整修复必须同时处理：

```text
首字母识别
+
固定分组顺序
+
中文组内排序
+
其他语言归一化
+
未知字符兜底
+
Unicode Code Point 安全
```

本次方案使用 Android 8.1 可用的 ICU `AlphabeticIndex` 获取中文拼音索引字母，使用 `Locale.CHINA` 的 `Collator` 处理中文组内排序，并通过 Unicode Normalizer 和常见文字映射支持英文、重音拉丁文字及部分非拉丁文字。

最终将业务无关逻辑整理为 `MultilingualNameSortUtils`，以后可直接用于应用列表、联系人、文件、城市、音乐、设备或其他名称列表的 `A-Z、#` 分组排序。
